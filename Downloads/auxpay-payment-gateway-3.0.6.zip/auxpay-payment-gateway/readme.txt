=== AuxPay Payment Gateway ===
Contributors: auxpay
Tags: woocommerce, payment, credit card, ach, text-to-pay
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.2
Stable tag: 3.0.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A WooCommerce payment gateway that allows customers to pay using credit cards, ACH, or text-to-pay with AuxPay.

== Description ==

AuxPay Gateway is a WooCommerce payment gateway plugin that lets your customers pay seamlessly using:

* **Credit Card Payments**  
* **ACH Payments**  
* **Text to Pay** links  

It integrates with the AuxPay platform and supports both **classic WooCommerce checkout** and the new **WooCommerce Blocks checkout**.

= Features =

* Securely accept credit card payments
* ACH payments (no tokenization required)
* Text to Pay option that generates a secure link
* Built-in support of Auxpay SDK for card payments
* Payrix integration for card payments through PayFields
* Full/Partial Refunds for all AuxPay gateways
* Optional technology/convenience fee
* Customizable payment settings in admin
* Debug logs option for monitoring

= Requirements =

* WordPress 6.0+
* WooCommerce 7.0+
* PHP 7.2+

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/auxpay-payment-gateway` directory, or install directly through the **WordPress Plugins screen**.
2. Activate the plugin through the **Plugins** screen in WordPress.
3. Navigate to **WooCommerce → Settings → Payments**.
4. Locate **AuxPay** in the list of gateways and click **Manage**.
5. Enter your **AuxPay API credentials** (provided in your AuxPay merchant account).
6. Enable the payment methods you want (Credit Card, ACH, or Text to Pay).
7. Save changes and start accepting payments.

== Usage ==

After installation and configuration:

1. Customers will see **Credit Card Payment**, **ACH Payment**, or **Text to Pay** on the checkout page.  
2. When paying with **Credit Card** or **ACH**, customers enter their payment details securely during checkout.  
3. When selecting **Text to Pay**, a secure payment link will be sent to the customer’s phone number for completing the payment.  
4. Orders are automatically updated in WooCommerce when the payment is processed.  
5. Admins can view transaction details in the WooCommerce **Order Details** page.

== Frequently Asked Questions ==

= Does this plugin work with WooCommerce Checkout Blocks? =  
Yes, AuxPay Gateway supports both the classic checkout and the new Checkout Block.

= Do I need SSL on my site? =  
Yes, for security reasons your site must use HTTPS when accepting live payments.

= Where can I find API credentials? =  
API keys are provided in your AuxPay merchant account. Contact AuxPay support if you don’t have them.

= Does this plugin store card data? =  
No. All sensitive card and ACH data are handled securely by AuxPay’s API. The plugin does not store payment details.

== Screenshots ==

1. AuxPay gateways listings in WooCommerce  
2. AuxPay gateways settings in WooCommerce  
3. Checkout page with AuxPay payment methods  

== Changelog ==

= 3.0.6 =
* 3DS flow with consent

= 3.0.5 =
* 3D Secure (3DS) flow implemented
* Configuration webhook added

= 3.0.4 =
* Dynamic display of credit card logos
* Security checks as per WordPress guidelines

= 3.0.3 =
* Dynamic gateway support for credit card payments
* Code improvements and fixes

= 3.0.2 =
* Added support for Payrix Payment Gateway
* Refunds support for all gateways
* Updated configuration settings for merchant
* Security check added on payment fields
* Logger added for error monitoring

= 3.0.1 =
* Initial release on WordPress.org
* Added Credit Card, ACH, and Text to Pay gateways
* WooCommerce Blocks checkout support
* Technology/convenience fee support

== Upgrade Notice ==

= 3.0.6 =
3DS flow, with user consent.

= 3.0.5 =
3DS flow, auto configuration through webhook.

= 3.0.4 =
Dynamic display of credit card logos, Security checks.

= 3.0.3 =
Dynamic gateway support for credit card payments.

= 3.0.2 =
Payrix Gateway, Refunds, Security check and error monitoring. Recommended update for all users.

= 3.0.1 =
First stable release with support for AuxPay Credit Card, ACH, and Text to Pay.
