<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_AuxPay_Card extends WC_Payment_Gateway {

    private $api_key;
    private $api_url;
    private $merchant_id;
    private $client_token;
    private $environment;
    private $payrix_api;
    private $payrix_mid;
    public  $is_payrix;
    public  $test_mode;

    public function __construct() {
        $this->id = 'wc_auxpay_card';
        $this->method_title = __('AuxPay - Credit Card', 'auxpay-payment-gateway');
        $this->method_description = 'Pay securely using credit card.';

        $this->has_fields = true;
        $this->supports = ['products', 'subscriptions', 'refunds'];

        $this->init_form_fields();
        $this->init_settings();

        if ('no' === get_option('wc_auxpay_test_enabled')) {
            $this->test_mode   = '';
            $this->environment = 'production';
        }
        else {
            $this->test_mode   = ' - (Test Mode)';
            $this->environment = 'sandbox';
        }

        $payrix = get_option('wc_auxpay_payrix_config');
        if (is_array($payrix) && $payrix['enabled']) {
            $this->payrix_api = $payrix['processorId'];
            $this->payrix_mid = $payrix['gMerchantId'];
            $this->is_payrix  = true;
        }
        else {
            $this->payrix_api = '';
            $this->payrix_mid = '';
            $this->is_payrix  = false;
        }

        $this->enabled     = $this->get_option('enabled');
        $this->title       = get_option('wc_auxpay_cc_title') . $this->test_mode;
        $this->description = get_option('wc_auxpay_cc_description');
        $this->api_key     = get_option('wc_auxpay_api_key');
        $this->api_url     = get_option('wc_auxpay_api_url');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
        
        // Blocks checkout hook
        add_action('woocommerce_rest_checkout_process_payment_with_context', [$this, 'process_payment_with_context'], 10, 2);

        // Payment scripts
        add_action('wp_enqueue_scripts', [$this, 'payment_scripts']);
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'       => 'Enable/Disable',
                'label'       => 'Credit Card Payment',
                'type'        => 'checkbox',
                'default'     => 'no',
            ),
        );
    }

    public function get_client_token() {
        try {
            $token    = get_transient('wc_auxpay_client_token');
            $merchant = get_transient('wc_auxpay_merchant_id');
            $expiry   = get_transient('wc_auxpay_token_expiry');

            if ($token && $expiry > time()) {
                $this->client_token = $token;
                $this->merchant_id = $merchant;
            }
            else {
                $response = wp_remote_post($this->api_url . '/client-token', [
                    'headers' => ['Content-Type'  => 'application/json'],
                    'body' => json_encode(['api_key' => $this->api_key]),
                    'timeout' => 15,
                ]);

                if (is_wp_error($response)) {
                    throw new Exception(esc_html($response->get_error_message()));
                }

                $body = json_decode(wp_remote_retrieve_body($response), true);

                if (isset($body['status']) && in_array($body['status'], ['success', '201']) && !empty($body['data'])) {
                    $expires_in = $body['data']['expires_in'];
                    $this->client_token = $body['data']['client_token'];
                    $this->merchant_id = $body['data']['merchant']['id'];
                    set_transient('wc_auxpay_client_token', $this->client_token, $expires_in);
                    set_transient('wc_auxpay_merchant_id', $this->merchant_id, $expires_in);
                    set_transient('wc_auxpay_token_expiry', time() + $expires_in, $expires_in);
                }
            }
        } catch (Exception $e) {
            wc_add_notice('Token Error: ' . $e->getMessage(), 'error');
        }
    }

    public function payment_fields() {
        echo '<p>' . esc_html($this->description) . '</p>';
        if ($this->is_payrix) {
            echo '
                <style>
                    .payfields {
                        padding: 10px;
                        overflow: auto;
                    }
                    .payfields #form-container {
                        width: 315px;
                    }
                    .payfields .label {
                        font-size: 14px !important;
                        font-weight: 500 !important;
                        color: #616161 !important;
                    }
                    .payfields .label.hide {
                        display: none;
                    }
                    .payfields .form-row {
                        height: 60px;
                        width: 315px;
                    }
                    .payfields .card-input-wrapper {
                        display: flex;
                        gap: 12px;
                    }
                    .payfields .card-input-wrapper .form-row {
                        width: auto;
                    }
                    .payfields .card-input-wrapper .w-50 {
                        width: 50%;
                    }
                </style>
                <div class="payfields">
                    <form>
                        <div id="form-container">
                            <label htmlFor="cc_number" class="label hide">Card Number:</label>
                            <div id="cc_number" class="form-row"></div>
                            <div class="card-input-wrapper">
                                <div class="w-50">
                                    <label htmlFor="cc_expiry" class="label hide">Expiration:</label>
                                    <div id="cc_expiry" class="form-row"></div>
                                </div>
                                <div class="w-50">
                                    <label htmlFor="cc_cvv" class="label hide">CVV:</label>
                                    <div id="cc_cvv" class="form-row"></div>
                                </div>
                            </div>
                            <label htmlFor="cc_name" class="label hide">Cardholder Name:</label>
                            <div id="cc_name" class="form-row"></div>
                        </div>
                    </form>
                </div>';
        }
        else {
            echo '
                <style>
                    #auxpay_card_fields_container iframe {
                        height: 265px !important;
                        margin: 0 -10px;
                    }
                </style>
                <div id="auxpay_card_fields_container"></div>';
        }
        echo '<input type="hidden" id="payment_token" name="payment_token" />';
        wp_nonce_field($this->id, 'wc_auxpay_card_nonce');
    }

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        try {
            // Verify nonce
            if (!isset($_POST['wc_auxpay_card_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wc_auxpay_card_nonce'])), $this->id)) {
                wc_add_notice('Security check failed. Please refresh and try again.', 'error');
                return;
            }
            // Collect payment token
            $payment_token = sanitize_text_field(wp_unslash($_POST['payment_token'] ?? ''));

            if (empty($payment_token)) {
                wc_add_notice('Payment token missing, please try again.', 'error');
                return;
            }

            // Prepare data to send to your API
            $payment_data = $this->prepare_payment_data($order, $payment_token);

            // Make the payment
            $response = $this->make_payment($payment_data);

            // Handle the response from the payment gateway
            if (in_array($response['status'], ['success', '201']) || $response['data']['Status'] == '1') {
                $order->payment_complete();
                $order->set_transaction_id($response['data']['TransactionId']);
                $order->save();

                $order->add_order_note('Transaction ID: ' . $response['data']['TransactionId']);
                wc_reduce_stock_levels($order_id);

                return array(
                    'result'   => 'success',
                    'redirect' => $this->get_return_url($order),
                );
            } else {
                wc_add_notice('Payment Failed: ' . $response['message'], 'error');
                $this->debug_log('Card Payment Failed. order#' . $order_id . ': ' . $response['message'], 'error');
                return;
            }
        } catch (Exception $e) {
            wc_add_notice('Payment Error: ' . $e->getMessage(), 'error');
            $this->debug_log('Card Payment Error. order#' . $order_id . ': ' . $e->getMessage(), 'error');
            return;
        }
    }

    public function process_payment_with_context($context, $request) {
        if ($context->payment_method === $this->id) {
            $order = $context->order;
            try {
                // Collect payment token
                $payment_token = sanitize_text_field(wp_unslash($context->payment_data['payment_token'] ?? ''));

                if (empty($payment_token)) {
                    wc_add_notice('Payment token missing, please try again.', 'error');
                    return;
                }

                // Prepare payment data
                $payment_data = $this->prepare_payment_data($order, $payment_token);

                // Make the payment
                $response = $this->make_payment($payment_data);

                // Handle the response from the payment gateway
                if (in_array($response['status'], ['success', '201']) || $response['data']['Status'] == '1') {
                    $order->payment_complete();
                    $order->set_transaction_id($response['data']['TransactionId']);
                    $order->save();

                    $order->add_order_note('Transaction ID: ' . $response['data']['TransactionId']);
                    wc_reduce_stock_levels($order->get_id());

                    $request->set_status('success');
                    $request->set_redirect_url($this->get_return_url($order));
                } else {
                    wc_add_notice('Payment Failed: ' . $response['message'], 'error');
                    $this->debug_log('Card Payment Failed. order#' . $order->get_id() . ': ' . $response['message'], 'error');
                    return;
                }
            } catch (Exception $e) {
                wc_add_notice('Payment Error: ' . $e->getMessage(), 'error');
                $this->debug_log('Card Payment Error. order#' . $order->get_id() . ': ' . $e->getMessage(), 'error');
                return;
            }
        }
    }

    private function prepare_payment_data($order, $payment_token) {
        $fee_active = false;
        $config = get_option('wc_auxpay_fee_config');
        if (is_array($config['card']) && $config['card']['active'] && 'yes' === get_option('wc_auxpay_fee_enabled')) {
            $fee_active = true;
        }

        // Extract billing information from the order
        $billing_address = array(
            "BillingCustomerName"   => $order->get_formatted_billing_full_name(),
            "BillingEmail"          => $order->get_billing_email(),
            "BillingPhoneNumber"    => $order->get_billing_phone(),
            "BillingAddress"        => $order->get_billing_address_1(),
            "BillingPostalCode"     => $order->get_billing_postcode(),
            "BillingCity"           => $order->get_billing_city(),
            "BillingState"          => $order->get_billing_state(),
            "BillingCountry"        => $order->get_billing_country(),
            "BillingCountryCode"    => "+1",
        );

        // Prepare the API request data
        $data = array_merge($billing_address, array(
            "Amount"               => (float)number_format((float)$order->get_total(), 2, '.', ''),
            "token"                => $payment_token,
            "SuggestedMode"        => "Card",
            "ConvenienceFeeActive" => $fee_active,
            "isPayrix"             => $this->is_payrix,
            "TransactionType"      => 1,
            "request-origin"       => 'woocommerce'
        ));

        return $data;
    }

    private function make_payment($payment_data) {

        $response = wp_remote_post($this->api_url . '/transaction', [
            'headers' => [
                'Authorization' => $this->api_key,
                'Content-Type'  => 'application/json',
            ],
            'body' => json_encode($payment_data),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            throw new Exception(esc_html($response->get_error_message()));
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        return array(
            'status' => $body['status'],
            'message' => $body['message'] ?? 'Unknown error',
            'data' => $body['data']
        );
    }

    public function process_refund($order_id, $amount = null, $reason = '') {
        $order = wc_get_order($order_id);
        try {
            if (!$order) return new WP_Error('invalid_order', 'Invalid order ID');
            if (!$amount || $amount <= 0) return new WP_Error('invalid_refund_amount', 'Refund amount must be greater than 0');

            // Prepare refund payload
            $payload = array(
                'Amount'         => $amount,
                'Reason'         => $reason,
                'TransactionFor' => "Refund",
                'TransactionId'  => $order->get_transaction_id(),
            );

            // Send refund request
            $response = $this->send_refund_request($payload);

            // Handle the response from the payment gateway
            if (in_array($response['status'], ['success', '201']) || $response['data']['Status'] == '1') {
                $order->add_order_note(sprintf('Refunded %1$s via AuxPay Gateway. Reason: %2$s', wc_price($amount), $reason ?? 'No reason provided.'));
                return true;
            } else {
                return new WP_Error('refund_failed', $response['message']);
            }
        } catch (Exception $e) {
            return new WP_Error('refund_error', $e->getMessage());
        }
    }

    private function send_refund_request($payload) {

        $response = wp_remote_post($this->api_url . '/refund', [
            'headers' => [
                'Authorization' => $this->api_key,
                'Content-Type'  => 'application/json',
            ],
            'body' => json_encode($payload),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            throw new Exception(esc_html($response->get_error_message()));
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        return array(
            'status' => $body['status'],
            'message' => $body['message'] ?? 'Unknown error',
            'data' => $body['data']
        );
    }

    private function debug_log($message, $level = 'info') {
        if ('yes' === get_option('wc_auxpay_logs_enabled')) {
            $logger  = wc_get_logger();
            $context = array('source' => 'auxpay-payment-gateway');
            $logger->log($level, $message, $context);
        }
    }

    public function admin_options() {
        $settings_url = admin_url('admin.php?page=wc-settings&tab=wc_auxpay_settings');
        wp_safe_redirect($settings_url);
        exit;
    }

    public function payment_scripts() {
        if ( !is_checkout() ) return;
        if ($this->enabled !== 'yes') return;

        if ($this->is_payrix) {
            // Payrix script
            $sdk_url  = $this->environment === 'production' ? 'https://api.payrix.com/payFieldsScript' : 'https://test-api.payrix.com/payFieldsScript';
            // Payrix data
            $sdk_data = [
                'apiKey'     => $this->payrix_api,
                'merchantID' => $this->payrix_mid,
                'gatewayID'  => $this->id,
            ];
            // Checkout script
            $script_path = WC_AUXPAY_PLUGIN_DIR . 'assets/js/dist/auxpay-payrix-checkout';
        }
        else {
            // Get client token
            $this->get_client_token();
            // AuxPay script
            $sdk_url  = $this->api_url . '/sdk/payment-sdk.js';
            // AuxPay data
            $sdk_data = [
                'environment' => $this->environment,
                'merchantURL' => get_site_url(),
                'merchantID'  => $this->merchant_id,
                'clientToken' => $this->client_token,
                'hostedUrl'   => $this->api_url . '/sdk/',
                'gatewayID'   => $this->id,
            ];
            // Checkout script
            $script_path = WC_AUXPAY_PLUGIN_DIR . 'assets/js/dist/auxpay-card-checkout';
        }

        $script_url  = $script_path . '.js';
		$asset_path  = $script_path . '.asset.php';
		$asset_url   = file_exists($asset_path)
        ? require($asset_path)
        : array(
            'dependencies' => array(),
            'version' => WC_AUXPAY_VERSION
        );

        // Enqueue SDK
        wp_enqueue_script('wc-auxpay-sdk', $sdk_url, ['jquery'], WC_AUXPAY_VERSION, true);
        array_push($asset_url['dependencies'], 'jquery', 'wc-auxpay-sdk');
        // Enqueue Checkout
        wp_enqueue_script('wc-auxpay-card-checkout', $script_url, $asset_url['dependencies'], $asset_url['version'], true);
        // Localize Checkout with SDK data
        wp_localize_script('wc-auxpay-card-checkout', 'WCAuxPayCard', $sdk_data);
    }
}
