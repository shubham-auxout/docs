jQuery(function ($) {
  $('#wc-auxpay-test-connection').on('click', function (e) {
    e.preventDefault();
    $.post(WCAuxPayGateway.ajax_url, {
      action: 'wc_auxpay_test_connection',
      nonce: WCAuxPayGateway.nonce,
    }, function (response) {
      console.log(response);
      alert(response.success && response.data.status == 200 ? '✅ Connection Successful' : '❌ ' + response.data.message);
    });
  });

  $('#wc-auxpay-fetch-config').on('click', function (e) {
    e.preventDefault();
    $.post(WCAuxPayGateway.ajax_url, {
      action: 'wc_auxpay_fetch_config',
      nonce: WCAuxPayGateway.nonce,
    }, function (response) {
      console.log(response);
      alert(response.success && response.data.status == 'success' ? '✅ Settings Fetched Successfully' : '❌ ' + response.data.message);
      location.reload();
    });
  });
});
